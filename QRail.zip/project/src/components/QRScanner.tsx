import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  QrCode, 
  Camera, 
  Upload, 
  Search, 
  CheckCircle, 
  AlertTriangle,
  Package,
  Calendar,
  User,
  MapPin
} from 'lucide-react';

interface ScannedData {
  id: string;
  type: string;
  vendor: string;
  manufacturingDate: string;
  warrantyExpiry: string;
  batchNumber: string;
  location: string;
  status: 'active' | 'warning' | 'expired';
  qualityGrade: string;
  inspectionHistory: number;
}

const QRScanner: React.FC = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [scannedData, setScannedData] = useState<ScannedData | null>(null);
  const [manualInput, setManualInput] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const sampleData: ScannedData = {
    id: 'ERC-2024-001234',
    type: 'Elastic Rail Clip',
    vendor: 'Jindal Steel Works Ltd.',
    manufacturingDate: '2024-03-15',
    warrantyExpiry: '2027-03-15',
    batchNumber: 'JSW-ERC-2024-A15',
    location: 'New Delhi Division - Section 12A',
    status: 'active',
    qualityGrade: 'A+',
    inspectionHistory: 3
  };

  const handleScanQR = () => {
    setIsScanning(true);
    // Simulate QR scanning process
    setTimeout(() => {
      setScannedData(sampleData);
      setIsScanning(false);
    }, 2000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Simulate QR code reading from image
      setTimeout(() => {
        setScannedData(sampleData);
      }, 1000);
    }
  };

  const handleManualSearch = () => {
    if (manualInput.trim()) {
      // Simulate manual search
      setTimeout(() => {
        setScannedData({
          ...sampleData,
          id: manualInput.trim()
        });
      }, 1000);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'expired': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case 'expired': return <AlertTriangle className="w-5 h-5 text-red-500" />;
      default: return <Package className="w-5 h-5 text-gray-500" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">QR Code Scanner</h1>
          <p className="text-gray-600 mt-2">Scan track fittings for instant identification and tracking</p>
        </div>

        {/* Scanner Options */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Camera Scan */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="text-center">
              <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <Camera className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Camera Scan</h3>
              <p className="text-gray-600 mb-4">Use device camera to scan QR code</p>
              <button
                onClick={handleScanQR}
                disabled={isScanning}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 transition-colors"
              >
                {isScanning ? 'Scanning...' : 'Start Camera'}
              </button>
            </div>
          </div>

          {/* Upload Image */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="text-center">
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <Upload className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload Image</h3>
              <p className="text-gray-600 mb-4">Upload QR code image from gallery</p>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                ref={fileInputRef}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full bg-green-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-green-700 transition-colors"
              >
                Choose Image
              </button>
            </div>
          </div>

          {/* Manual Entry */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="text-center">
              <div className="mx-auto w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                <Search className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Manual Entry</h3>
              <p className="text-gray-600 mb-4">Enter fitting ID manually</p>
              <div className="space-y-2">
                <input
                  type="text"
                  placeholder="Enter Fitting ID"
                  value={manualInput}
                  onChange={(e) => setManualInput(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
                <button
                  onClick={handleManualSearch}
                  className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg font-medium hover:bg-purple-700 transition-colors"
                >
                  Search
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Scanning Animation */}
        {isScanning && (
          <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
            <div className="text-center">
              <div className="mx-auto w-32 h-32 border-4 border-blue-600 rounded-lg relative mb-4">
                <div className="absolute inset-0 border-2 border-blue-400 rounded-lg animate-pulse"></div>
                <div className="absolute inset-2 border-2 border-blue-300 rounded-lg animate-ping"></div>
                <QrCode className="w-16 h-16 text-blue-600 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              </div>
              <p className="text-lg font-medium text-gray-900 mb-2">Scanning QR Code...</p>
              <p className="text-gray-600">Please hold steady and ensure good lighting</p>
            </div>
          </div>
        )}

        {/* Scanned Results */}
        {scannedData && (
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  {getStatusIcon(scannedData.status)}
                  <div>
                    <h2 className="text-xl font-semibold text-white">{scannedData.id}</h2>
                    <p className="text-blue-100">{scannedData.type}</p>
                  </div>
                </div>
                <span className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(scannedData.status)}`}>
                  {scannedData.status.toUpperCase()}
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Basic Information */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <User className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Vendor</p>
                        <p className="font-medium text-gray-900">{scannedData.vendor}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Package className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Batch Number</p>
                        <p className="font-medium text-gray-900">{scannedData.batchNumber}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <MapPin className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Location</p>
                        <p className="font-medium text-gray-900">{scannedData.location}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Dates & Quality */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Quality & Timeline</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Calendar className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Manufacturing Date</p>
                        <p className="font-medium text-gray-900">{scannedData.manufacturingDate}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Calendar className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Warranty Expiry</p>
                        <p className="font-medium text-gray-900">{scannedData.warrantyExpiry}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-gray-400" />
                      <div>
                        <p className="text-sm text-gray-600">Quality Grade</p>
                        <p className="font-medium text-green-600">{scannedData.qualityGrade}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="flex flex-wrap gap-4">
                  <Link
                    to={`/item/${scannedData.id}`}
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
                  >
                    View Full Details
                  </Link>
                  <button className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                    Update Inspection
                  </button>
                  <button className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                    Report Issue
                  </button>
                  <button 
                    onClick={() => setScannedData(null)}
                    className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                  >
                    Scan Another
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Recent Scans */}
        {!scannedData && !isScanning && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Scans</h3>
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <QrCode className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="font-medium text-gray-900">ERC-2024-00123{i}</p>
                      <p className="text-sm text-gray-600">Elastic Rail Clip - Scanned 2 hours ago</p>
                    </div>
                  </div>
                  <Link
                    to={`/item/ERC-2024-00123${i}`}
                    className="text-blue-600 hover:text-blue-700 font-medium text-sm"
                  >
                    View Details
                  </Link>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QRScanner;