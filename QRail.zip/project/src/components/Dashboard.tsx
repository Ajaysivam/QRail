import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Package, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  QrCode,
  BarChart3,
  Users,
  Calendar,
  Search
} from 'lucide-react';

interface DashboardStats {
  totalFittings: number;
  scannedToday: number;
  qualityIssues: number;
  warrantyExpiring: number;
}

interface RecentActivity {
  id: string;
  type: string;
  item: string;
  vendor: string;
  timestamp: string;
  status: 'success' | 'warning' | 'error';
}

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalFittings: 0,
    scannedToday: 0,
    qualityIssues: 0,
    warrantyExpiring: 0
  });

  const [recentActivities, setRecentActivities] = useState<RecentActivity[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Simulate loading dashboard data
    setStats({
      totalFittings: 23500000,
      scannedToday: 1247,
      qualityIssues: 23,
      warrantyExpiring: 156
    });

    setRecentActivities([
      {
        id: '1',
        type: 'Rail Clip',
        item: 'ERC-2024-001234',
        vendor: 'Jindal Steel Works',
        timestamp: '2025-01-27 14:30',
        status: 'success'
      },
      {
        id: '2',
        type: 'Rail Pad',
        item: 'RP-2024-005678',
        vendor: 'SAIL Corporation',
        timestamp: '2025-01-27 14:25',
        status: 'warning'
      },
      {
        id: '3',
        type: 'Liner',
        item: 'LN-2024-009876',
        vendor: 'Tata Steel',
        timestamp: '2025-01-27 14:20',
        status: 'success'
      },
      {
        id: '4',
        type: 'Rail Clip',
        item: 'ERC-2024-001235',
        vendor: 'JSW Steel',
        timestamp: '2025-01-27 14:15',
        status: 'error'
      }
    ]);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'error': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-2">Railway Track Fitting Management System Overview</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-blue-500">
            <div className="flex items-center">
              <Package className="w-8 h-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Fittings</p>
                <p className="text-2xl font-bold text-gray-900">
                  {(stats.totalFittings / 1000000).toFixed(1)}M
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-green-500">
            <div className="flex items-center">
              <QrCode className="w-8 h-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Scanned Today</p>
                <p className="text-2xl font-bold text-gray-900">{stats.scannedToday.toLocaleString()}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-red-500">
            <div className="flex items-center">
              <AlertTriangle className="w-8 h-8 text-red-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Quality Issues</p>
                <p className="text-2xl font-bold text-gray-900">{stats.qualityIssues}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-yellow-500">
            <div className="flex items-center">
              <Clock className="w-8 h-8 text-yellow-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Warranty Expiring</p>
                <p className="text-2xl font-bold text-gray-900">{stats.warrantyExpiring}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Link 
            to="/scanner" 
            className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
          >
            <QrCode className="w-8 h-8 mb-3" />
            <h3 className="text-lg font-semibold mb-2">Scan QR Code</h3>
            <p className="text-blue-100">Scan track fitting QR codes for instant identification</p>
          </Link>

          <Link 
            to="/analytics" 
            className="bg-gradient-to-r from-green-600 to-green-700 text-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
          >
            <BarChart3 className="w-8 h-8 mb-3" />
            <h3 className="text-lg font-semibold mb-2">View Analytics</h3>
            <p className="text-green-100">AI-powered insights and performance reports</p>
          </Link>

          <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white p-6 rounded-lg shadow-sm">
            <Users className="w-8 h-8 mb-3" />
            <h3 className="text-lg font-semibold mb-2">Portal Integration</h3>
            <p className="text-purple-100">Connected to UDM and TMS portals</p>
          </div>
        </div>

        {/* Recent Activity and Search */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Recent Scans</h2>
              </div>
              <div className="p-6">
                <div className="space-y-4">
                  {recentActivities.map((activity) => (
                    <div key={activity.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${getStatusColor(activity.status).split(' ')[1]}`}></div>
                        <div>
                          <p className="font-medium text-gray-900">{activity.item}</p>
                          <p className="text-sm text-gray-600">{activity.type} - {activity.vendor}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">{activity.timestamp}</p>
                        <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(activity.status)}`}>
                          {activity.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="space-y-6">
            {/* Search */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Search</h3>
              <div className="relative">
                <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by item ID, vendor..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            {/* Quality Alerts */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quality Alerts</h3>
              <div className="space-y-3">
                <div className="flex items-center p-3 bg-red-50 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-red-500 mr-3" />
                  <div>
                    <p className="text-sm font-medium text-red-800">3 Faulty Clips</p>
                    <p className="text-xs text-red-600">Vendor: ABC Steel</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
                  <Clock className="w-5 h-5 text-yellow-500 mr-3" />
                  <div>
                    <p className="text-sm font-medium text-yellow-800">Warranty Expiring</p>
                    <p className="text-xs text-yellow-600">156 items this month</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Performance Summary */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Today's Performance</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Scan Success Rate</span>
                  <span className="font-semibold text-green-600">98.5%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Quality Pass Rate</span>
                  <span className="font-semibold text-blue-600">97.2%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Active Inspectors</span>
                  <span className="font-semibold text-gray-900">47</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;