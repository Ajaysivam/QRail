import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft,
  Package,
  Calendar,
  User,
  MapPin,
  CheckCircle,
  AlertTriangle,
  FileText,
  Wrench,
  BarChart3,
  History,
  Download,
  Edit
} from 'lucide-react';

interface ItemDetail {
  id: string;
  type: string;
  vendor: string;
  manufacturingDate: string;
  warrantyExpiry: string;
  batchNumber: string;
  location: string;
  status: 'active' | 'warning' | 'expired';
  qualityGrade: string;
  specifications: {
    material: string;
    dimensions: string;
    weight: string;
    coating: string;
  };
  inspections: Array<{
    date: string;
    inspector: string;
    result: string;
    notes: string;
  }>;
  performance: {
    lifeExpectancy: string;
    failureRate: string;
    maintenanceSchedule: string;
  };
}

const ItemDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [item, setItem] = useState<ItemDetail | null>(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    // Simulate API call to fetch item details
    setTimeout(() => {
      setItem({
        id: id || 'ERC-2024-001234',
        type: 'Elastic Rail Clip',
        vendor: 'Jindal Steel Works Ltd.',
        manufacturingDate: '2024-03-15',
        warrantyExpiry: '2027-03-15',
        batchNumber: 'JSW-ERC-2024-A15',
        location: 'New Delhi Division - Section 12A',
        status: 'active',
        qualityGrade: 'A+',
        specifications: {
          material: 'High Carbon Steel',
          dimensions: '150mm x 75mm x 25mm',
          weight: '2.5 kg',
          coating: 'Zinc Galvanized'
        },
        inspections: [
          {
            date: '2025-01-15',
            inspector: 'Rajesh Kumar',
            result: 'Passed',
            notes: 'All parameters within acceptable range'
          },
          {
            date: '2024-10-15',
            inspector: 'Priya Sharma',
            result: 'Passed',
            notes: 'Minor surface wear, within tolerance'
          },
          {
            date: '2024-07-15',
            inspector: 'Amit Singh',
            result: 'Passed',
            notes: 'Excellent condition'
          }
        ],
        performance: {
          lifeExpectancy: '8-10 years',
          failureRate: '0.02%',
          maintenanceSchedule: 'Every 6 months'
        }
      });
    }, 500);
  }, [id]);

  if (!item) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading item details...</p>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'expired': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Package },
    { id: 'inspections', label: 'Inspections', icon: CheckCircle },
    { id: 'performance', label: 'Performance', icon: BarChart3 },
    { id: 'maintenance', label: 'Maintenance', icon: Wrench }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Link 
            to="/dashboard" 
            className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Link>
          
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">{item.id}</h1>
                <p className="text-lg text-gray-600 mt-1">{item.type}</p>
                <div className="flex items-center space-x-4 mt-3">
                  <span className={`inline-flex px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(item.status)}`}>
                    {item.status.toUpperCase()}
                  </span>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Grade {item.qualityGrade}
                  </span>
                </div>
              </div>
              <div className="flex space-x-3 mt-4 md:mt-0">
                <button className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                  <Edit className="w-4 h-4 mr-2" />
                  Update
                </button>
                <button className="inline-flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors">
                  <Download className="w-4 h-4 mr-2" />
                  Report
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                      activeTab === tab.id
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'overview' && (
            <div className="grid md:grid-cols-2 gap-6">
              {/* Basic Information */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <User className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-600">Vendor</p>
                      <p className="font-medium text-gray-900">{item.vendor}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Package className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-600">Batch Number</p>
                      <p className="font-medium text-gray-900">{item.batchNumber}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-600">Current Location</p>
                      <p className="font-medium text-gray-900">{item.location}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-600">Manufacturing Date</p>
                      <p className="font-medium text-gray-900">{item.manufacturingDate}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Calendar className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="text-sm text-gray-600">Warranty Expiry</p>
                      <p className="font-medium text-gray-900">{item.warrantyExpiry}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Specifications */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Technical Specifications</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600">Material</p>
                    <p className="font-medium text-gray-900">{item.specifications.material}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Dimensions</p>
                    <p className="font-medium text-gray-900">{item.specifications.dimensions}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Weight</p>
                    <p className="font-medium text-gray-900">{item.specifications.weight}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Coating</p>
                    <p className="font-medium text-gray-900">{item.specifications.coating}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'inspections' && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Inspection History</h3>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  Add Inspection
                </button>
              </div>
              
              <div className="space-y-4">
                {item.inspections.map((inspection, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <div>
                          <p className="font-medium text-gray-900">{inspection.date}</p>
                          <p className="text-sm text-gray-600">Inspector: {inspection.inspector}</p>
                        </div>
                      </div>
                      <span className="inline-flex px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                        {inspection.result}
                      </span>
                    </div>
                    <p className="text-gray-700">{inspection.notes}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'performance' && (
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600">Life Expectancy</p>
                    <p className="font-medium text-gray-900">{item.performance.lifeExpectancy}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Failure Rate</p>
                    <p className="font-medium text-green-600">{item.performance.failureRate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Maintenance Schedule</p>
                    <p className="font-medium text-gray-900">{item.performance.maintenanceSchedule}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Quality Assessment</h3>
                <div className="space-y-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                      <span className="font-medium text-green-800">Excellent Condition</span>
                    </div>
                    <p className="text-green-700 text-sm">
                      AI analysis indicates optimal performance with no immediate maintenance required.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-gray-700">Quality Score: 94/100</p>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{ width: '94%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'maintenance' && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Maintenance Schedule</h3>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                  Schedule Maintenance
                </button>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Upcoming Maintenance</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">Routine Inspection</p>
                        <p className="text-sm text-gray-600">Due: March 15, 2025</p>
                      </div>
                      <Calendar className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">Coating Check</p>
                        <p className="text-sm text-gray-600">Due: June 15, 2025</p>
                      </div>
                      <Wrench className="w-5 h-5 text-yellow-500" />
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Maintenance History</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">Surface Cleaning</p>
                        <p className="text-sm text-gray-600">Completed: January 15, 2025</p>
                      </div>
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">Visual Inspection</p>
                        <p className="text-sm text-gray-600">Completed: October 15, 2024</p>
                      </div>
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ItemDetails;