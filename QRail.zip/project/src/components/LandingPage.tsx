import React from 'react';
import { Train, QrCode, Shield, BarChart3, Users, Clock, AlertTriangle, CheckCircle } from 'lucide-react';

interface LandingPageProps {
  onLogin: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onLogin }) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-700">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Train className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Railway Track Fitting Management</h1>
                <p className="text-sm text-gray-600">Indian Railways - Smart India Hackathon 2025</p>
              </div>
            </div>
            <button
              onClick={onLogin}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Login to System
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-5xl font-bold mb-6">
              Unified Track Fitting Identification System
            </h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto text-blue-100">
              Revolutionary QR code-based tracking system for 10 crore Elastic Rail Clips, 5 crore Liners, 
              and 8.5 crore Rail Pads with AI-powered quality monitoring and performance management.
            </p>
            <button
              onClick={onLogin}
              className="bg-orange-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-orange-600 transition-colors shadow-lg"
            >
              Access System Dashboard
            </button>
          </div>
        </div>
      </section>

      {/* Problem Statement */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Critical Challenge</h3>
            <p className="text-lg text-gray-600 max-w-4xl mx-auto">
              Currently, there is no system for identification of track fittings with integration to UDM portal, 
              creating gaps in quality assessment and performance management critical for railway safety.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-red-50 p-6 rounded-lg border-l-4 border-red-400">
              <AlertTriangle className="w-12 h-12 text-red-500 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">No Identification System</h4>
              <p className="text-gray-600">
                Track fittings lack proper identification, making quality monitoring and performance tracking impossible.
              </p>
            </div>
            <div className="bg-yellow-50 p-6 rounded-lg border-l-4 border-yellow-400">
              <Clock className="w-12 h-12 text-yellow-500 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Manual Processes</h4>
              <p className="text-gray-600">
                Current manual tracking is inefficient for managing millions of components annually.
              </p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg border-l-4 border-blue-400">
              <Shield className="w-12 h-12 text-blue-500 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Safety Concerns</h4>
              <p className="text-gray-600">
                Without proper tracking, identifying faulty components and ensuring safety becomes challenging.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Solution Features */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">Our Comprehensive Solution</h3>
            <p className="text-lg text-gray-600">
              Innovative laser-based QR coding with AI-powered analytics and seamless portal integration
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <QrCode className="w-12 h-12 text-blue-600 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">QR Code Scanning</h4>
              <p className="text-gray-600">Mobile-based scanning for instant identification and tracking</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <BarChart3 className="w-12 h-12 text-green-600 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">AI Analytics</h4>
              <p className="text-gray-600">Intelligent quality monitoring and exception detection</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <Users className="w-12 h-12 text-purple-600 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Portal Integration</h4>
              <p className="text-gray-600">Seamless integration with UDM and TMS portals</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <CheckCircle className="w-12 h-12 text-orange-600 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Quality Assurance</h4>
              <p className="text-gray-600">End-to-end quality monitoring from manufacturing to service</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-blue-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-orange-400 mb-2">10 Crore</div>
              <div className="text-lg">Elastic Rail Clips</div>
              <div className="text-sm text-blue-200">Annually procured</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-400 mb-2">5 Crore</div>
              <div className="text-lg">Liners</div>
              <div className="text-sm text-blue-200">Quality monitored</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-orange-400 mb-2">8.5 Crore</div>
              <div className="text-lg">Rail Pads</div>
              <div className="text-sm text-blue-200">Performance tracked</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-400">
            © 2025 Indian Railways - Smart India Hackathon Solution
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Advanced Track Fitting Management System with AI-Powered Quality Monitoring
          </p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;