import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Package,
  Users,
  Calendar,
  Download,
  Filter
} from 'lucide-react';

const Analytics: React.FC = () => {
  const [dateRange, setDateRange] = useState('7days');
  const [selectedMetric, setSelectedMetric] = useState('quality');

  const qualityData = [
    { vendor: 'Jindal Steel', grade: 'A+', count: 12500, percentage: 95.2 },
    { vendor: 'SAIL Corporation', grade: 'A', count: 8200, percentage: 88.7 },
    { vendor: 'Tata Steel', grade: 'A+', count: 9800, percentage: 92.1 },
    { vendor: 'JSW Steel', grade: 'A', count: 7600, percentage: 87.3 },
    { vendor: 'Essar Steel', grade: 'B+', count: 5200, percentage: 78.9 }
  ];

  const performanceMetrics = {
    totalScans: 45673,
    qualityPassed: 43821,
    issuesIdentified: 234,
    warrantyExpiring: 1618,
    successRate: 96.1,
    avgResponseTime: '0.8s'
  };

  const fittingTypes = [
    { type: 'Elastic Rail Clips', total: 18500, issues: 12, rate: 99.93 },
    { type: 'Rail Pads', total: 15200, issues: 8, rate: 99.95 },
    { type: 'Liners', total: 8900, issues: 5, rate: 99.94 },
    { type: 'Sleepers', total: 3073, issues: 2, rate: 99.93 }
  ];

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A+': return 'bg-green-100 text-green-800';
      case 'A': return 'bg-blue-100 text-blue-800';
      case 'B+': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Analytics & Reports</h1>
              <p className="text-gray-600 mt-2">AI-powered insights and performance monitoring</p>
            </div>
            <div className="flex space-x-3 mt-4 md:mt-0">
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="7days">Last 7 Days</option>
                <option value="30days">Last 30 Days</option>
                <option value="90days">Last 3 Months</option>
                <option value="1year">Last Year</option>
              </select>
              <button className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Download className="w-4 h-4 mr-2" />
                Export Report
              </button>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-blue-500">
            <div className="flex items-center">
              <BarChart3 className="w-8 h-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Scans</p>
                <p className="text-2xl font-bold text-gray-900">{performanceMetrics.totalScans.toLocaleString()}</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +12% vs last period
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-green-500">
            <div className="flex items-center">
              <CheckCircle className="w-8 h-8 text-green-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold text-gray-900">{performanceMetrics.successRate}%</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +0.8% vs last period
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-red-500">
            <div className="flex items-center">
              <AlertTriangle className="w-8 h-8 text-red-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Issues Identified</p>
                <p className="text-2xl font-bold text-gray-900">{performanceMetrics.issuesIdentified}</p>
                <p className="text-xs text-red-600 flex items-center mt-1">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +5 vs last period
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-yellow-500">
            <div className="flex items-center">
              <Calendar className="w-8 h-8 text-yellow-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Warranty Expiring</p>
                <p className="text-2xl font-bold text-gray-900">{performanceMetrics.warrantyExpiring}</p>
                <p className="text-xs text-yellow-600 flex items-center mt-1">
                  Next 30 days
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Charts and Analysis */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Quality by Vendor */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Quality Analysis by Vendor</h3>
              <Filter className="w-5 h-5 text-gray-400" />
            </div>
            <div className="space-y-4">
              {qualityData.map((vendor, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-gray-900">{vendor.vendor}</span>
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${getGradeColor(vendor.grade)}`}>
                        {vendor.grade}
                      </span>
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs text-gray-600">{vendor.count.toLocaleString()} items</span>
                      <span className="text-xs font-medium text-gray-900">{vendor.percentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${vendor.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Performance by Fitting Type */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Performance by Fitting Type</h3>
              <Package className="w-5 h-5 text-gray-400" />
            </div>
            <div className="space-y-4">
              {fittingTypes.map((fitting, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-900">{fitting.type}</span>
                    <span className="text-sm font-medium text-green-600">{fitting.rate}%</span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <span>{fitting.total.toLocaleString()} total</span>
                    <span className="text-red-600">{fitting.issues} issues</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ width: `${fitting.rate}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Insights */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">AI-Powered Insights</h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-green-50 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
                <div>
                  <h4 className="font-medium text-green-800 mb-2">Quality Trending Upward</h4>
                  <p className="text-green-700 text-sm">
                    Overall quality scores have improved by 3.2% over the last quarter. 
                    Jindal Steel and Tata Steel show exceptional consistency in A+ grades.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <BarChart3 className="w-6 h-6 text-blue-500 mt-1" />
                <div>
                  <h4 className="font-medium text-blue-800 mb-2">Predictive Maintenance Alert</h4>
                  <p className="text-blue-700 text-sm">
                    AI models predict 156 rail clips will require maintenance within 30 days based on 
                    usage patterns and environmental factors.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="w-6 h-6 text-yellow-500 mt-1" />
                <div>
                  <h4 className="font-medium text-yellow-800 mb-2">Vendor Performance Variation</h4>
                  <p className="text-yellow-700 text-sm">
                    Essar Steel shows 10% lower quality scores compared to other vendors. 
                    Recommend enhanced quality control measures.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-purple-50 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <TrendingUp className="w-6 h-6 text-purple-500 mt-1" />
                <div>
                  <h4 className="font-medium text-purple-800 mb-2">Efficiency Optimization</h4>
                  <p className="text-purple-700 text-sm">
                    Current scanning efficiency is 96.1%. Implementing mobile scanner upgrades 
                    could improve this to 98.5% based on pilot data.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Integration Status */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Portal Integration Status</h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="font-medium text-gray-900">UDM Portal (ireps.gov.in)</span>
                </div>
                <span className="text-sm text-green-600">Connected</span>
              </div>
              <p className="text-sm text-gray-600 mb-3">
                Real-time synchronization with User Depot Module for procurement and inventory data.
              </p>
              <div className="flex justify-between text-xs text-gray-500">
                <span>Last sync: 2 minutes ago</span>
                <span>1,247 records updated</span>
              </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <span className="font-medium text-gray-900">TMS Portal (irecept.gov.in)</span>
                </div>
                <span className="text-sm text-green-600">Connected</span>
              </div>
              <p className="text-sm text-gray-600 mb-3">
                Integration with Track Management System for operational performance tracking.
              </p>
              <div className="flex justify-between text-xs text-gray-500">
                <span>Last sync: 5 minutes ago</span>
                <span>892 inspections updated</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;