import React, { useState, useEffect } from 'react';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import Dashboard from './components/Dashboard';
import QRScanner from './components/QRScanner';
import ItemDetails from './components/ItemDetails';
import Analytics from './components/Analytics';
import Navigation from './components/Navigation';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Simulate authentication check
    const authStatus = localStorage.getItem('railway_auth');
    setIsAuthenticated(!!authStatus);
  }, []);

  const handleLogin = () => {
    localStorage.setItem('railway_auth', 'true');
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('railway_auth');
    setIsAuthenticated(false);
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        {isAuthenticated && <Navigation onLogout={handleLogout} />}
        <Routes>
          <Route 
            path="/" 
            element={
              !isAuthenticated ? 
                <LandingPage onLogin={handleLogin} /> : 
                <Dashboard />
            } 
          />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/scanner" element={<QRScanner />} />
          <Route path="/item/:id" element={<ItemDetails />} />
          <Route path="/analytics" element={<Analytics />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;